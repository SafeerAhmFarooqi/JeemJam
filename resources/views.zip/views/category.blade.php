@extends('layout')
@section('nav')

    <ul>
  
  <li class="dropdown"><a href="#news">Mobile</a>
  <div class="dropdown-content">
  @foreach($mobData as $data)
           <a  href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a>                        
     @endforeach
    </div>
  
  </li>
  <li class="dropdown"><a href="#news">Jobs</a>
  <div class="dropdown-content">
  @foreach($jobData as $data)
           <a  href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a>                        
     @endforeach
    </div>
  
  </li><li class="dropdown"><a href="#news">Service</a>
  <div class="dropdown-content">
  @foreach($serData as $data)
           <a  href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a>                        
     @endforeach
    </div>
  
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Miscellaneous</a>
    <div class="dropdown-content">
    @foreach($misData as $data)
           <a  href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a>                        
     @endforeach
    </div>
  </li>
  <li class="dropdown"><a href="#news">Cars</a>
  <div class="dropdown-content">
  @foreach($carData as $data)
           <a  href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a>                        
     @endforeach
    </div>
  
  </li>
</ul>
    
    @endsection
    @section('content')
              <div class="container-fluid px-4">
                        <div class="des" style="width:100%;margin-bottom:10px; ">
                            <div style="">
                            <center> 
                                <img style="width:100%;height:250px;" src="{{asset('frount belt.png')}}" alt="logo">
                           </center> 
                        </div>
                        <center>
                            <div style="margin-top:10px;width:200px;height:35px;background-color:green; border:1px solid green;border-radius:60px;">
                                <center><a style="text-decoration:none;color:black;"href="">Post your Ads for free</a></center>
                            </div></center>
                        </div>
              <div class="des">
                <div class="row">
                            <div class="col-xl-4 col-md-5">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;  background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-mobile"></i></h4></div>
                                    <h4 style="float:left;" >Mobile</h4>
                                </div>
                                @foreach($mobData as $data)
                                   
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.$data->sub_category.'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a></h5>
                                 </div>
                                  @endforeach
                            </div>
</div>
<div  class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-help"></i></h4></div>
                                    <h4 style="float:left;" >Miscellaneous</h4>
                                </div>
                                @foreach($misData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.$data->sub_category.'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a></h5>
                                 </div> 
                                 @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4 style="float:left;" >Job</h4>
                                </div>
                                @foreach($jobData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.$data->sub_category.'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a></h5>
                                 </div>
                                  @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-car"></i></h4></div>
                                    <h4 style="float:left;" >Cars</h4>
                                </div>
                                @foreach($carData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:50px;height:50px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                  @endforeach
                                </div>
</div>
<div style="float:left;"class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4 style="float:left;" >Services</h4>
                                </div>
                                @foreach($serData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:50px;height:50px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                @endforeach
                                </div>
</div>

                           
                            </div>
                        </div>
         </div>
         <div class="mob">
                        <div class="col-xl-4 col-md-5">
                                <div class="card  mb-4">
                                    <div class="card-body"style="margin-top:10px;color:black;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <h4 style="float:left;" >Categories</h4>
                                </div>
			   </a>  
                    <br>
                    <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-mobile"></i></h4></div>
                                    <h4><a style="color:black;text-decoration:none;" href="{{url('sub/mobile')}}">Mobiles
                    </a></h4> 
                                </div>
                                <br>
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-car"></i></h4></div>
                                    <h4><a style="color:black;text-decoration:none;" href="{{url('sub/cars')}}">Cars
                    </a></h4> 
                                </div>
                                 
                    <br>
                    <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; "> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4><a style="color:black;text-decoration:none;" href="{{url('sub/service')}}">Services</h4></a>  
                   
                                </div>
                   
                   
                    <br>
                    <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; "> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-help"></i></h4></div>
                                    <h4><a style="color:black;text-decoration:none;" href="{{url('sub/miscallenious')}}">Miscallenious
                    </a></h4>  
                    
                                </div>
                   <br>
                   <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey; "> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-user"></i></h4></div>
                                    <h4><a style="color:black;text-decoration:none;" href="{{url('sub/jobs')}}">Jobs
                    </a></h4>  
                                </div>
                  
                    <br>
                    <br>
  
</div>
                    
    </div> 
                
@endsection