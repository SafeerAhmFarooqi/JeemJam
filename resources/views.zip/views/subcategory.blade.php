@extends('layout')
    @section('content')
                        <div class="mob">
                        <div class="col-xl-4 col-md-5">
                                <div class="card  mb-4">
                                    <div class="card-body"style="margin-top:10px;color:black;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <h4 style="float:left;" >Sub Categories</h4>
                                </div>
			
            <br>
            <br>
            @foreach($subData as $data)
            <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.$data->sub_category.'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>                
                    <br> 
                    @endforeach
  
</div>
                    
 


@endsection