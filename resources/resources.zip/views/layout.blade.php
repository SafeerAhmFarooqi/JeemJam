<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Jeejam</title>
        <link href="{{asset('css/styles.css')}}" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav style="border-bottom:1px solid grey; background:blue;" class="sb-topnav navbar navbar-expand navbar">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" style="color:white;" href="index.html">Start Bootstrap</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" style="color:white;" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a style="color:white;" class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="#!">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav style="border-right:1px solid grey; background:blue;color:white;" class="sb-sidenav accordion sb-sidenav" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Home</div>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="index.html">
                                <div class="sb-nav-link-icon" ><i class="fas fa-home"></i></div>
                                Home
                            </a>
                            <div class="sb-sidenav-menu-heading">Categories</div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-mobile"></i></div>
                                Mobile
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Samsung</a>
                                    
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Iphone</a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Oppo</a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Nokia</a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Huawei</a>
                                    
                                </nav>
                            </div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Service
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Private Lesson
                                    </a>
                                    
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Taxi 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Labor Recruitment 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Contracting 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Removal Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Building, Home Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Business & Investment 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Formalities Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Maintenance Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Marketing Service 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Cleaning Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">General Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Advocates and Law 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Professional Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Travel Services & Tours 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Events Planning 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Agricultural Services 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Training & Tuition 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Car Service 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Health & Beauty 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Tax and Money 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Internet 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Rent a Car                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Shipping                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Pest Control                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Translation                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Real estate services                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Homemade Cooking                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Telecoms                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Loan                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Computers                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Human Resources                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Property                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Guard & Security                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Entertainment                                     
                                    </a><a class="nav-link"  style="color:white;" href="layout-static.html">Lost and Found                                    
                            </nav>
                            </div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-help"></i></div>
                                Miscellaneous
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                




                                    <a class="nav-link"  style="color:white;" href="layout-static.html"> Wholesale Deals </a>
                                    
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Furniture</a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Home Appliances </a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Equipments</a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Clothes </a>
                                    
                                </nav>
                            </div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Jobs
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">

                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Tourist and Restaurants  </a>
                                    
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Drivers </a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Engineering  </a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Labors </a>
                                    <a class="nav-link"  style="color:white;"  href="layout-sidenav-light.html">Accounting </a>
                                    
                                </nav>
                            </div>
                          
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-car"></i></div>
                               Cars
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                   <a class="nav-link"  style="color:white;" href="layout-static.html"> Toyota 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Nissan 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Hyunday 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Lexus 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Mercedes 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Mitsubishi 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Misc. cars 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Kia 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Chevrolet 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Ford 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Honda 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">BMW 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">GMC 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Jeep 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Volkswagen 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Infiniti 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Renault 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Dodge 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Land Rover 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Peugeot 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Mazda 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Suzuki 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Audi 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Isuzu 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Mini Cooper 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Cadillac 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Porsche 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Chrysler 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Volvo 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Import cars 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Rover 
                                </a>
                                <a class="nav-link"  style="color:white;" href="layout-static.html">Lincoln 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Daihatsu 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Jaguar 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Tata 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Fiat 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">JAC 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">MG 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Bentley 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Chery 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Smart 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Classic cars 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Daewoo 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Hummer 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Subaru 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">SsangYong 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Asia 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Ferrari 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Lada 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Mercury 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Opel 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Seat 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Skoda 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Aston Martin 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Datsun 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">DFSK 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Maserati 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Proton 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Rolls-Royce 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Citroen 
                                    </a>
                                    <a class="nav-link"  style="color:white;" href="layout-static.html">Dacia 
</a>

                                </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Pages</div>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="index.html">
                                About Us
                            </a>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="index.html">
                                Contact Us
                            </a>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="index.html">
                                Disclaimer
                            </a>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="index.html">
                                Privacy Policy
                            </a>
                            
                        </div>
                    </div>
                   
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                @yield('content')
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="{{asset('js/scripts.js')}}"></script>
       
    </body>
</html>
