@extends('layout')
@section('content')

<div>
    <center><h1 style="font-size:60px;"> <u>About Us</u> </h1></center> 
    
    <h5 style="margin:30px;">
    In the growing industry, the new needs
and demands arises with certain
problems that we encounter daily.
Jeemjam classifieds appeared to resolve
the upcoming expected hurdles to ease
the lives. So jeemjam.com shake hands the
users of all over the world.
 Jeemjam online classifieds want to
facilitate the users with couple of services
in innovative ways. We want you to look
no further when the bundle of solutions
unlocks here. Therefore, we come up with
a suitable and comfortable platform for
you to post your ad, a vehicle to buy and
enjoy new gadgets. When looking for a
new job or to become an employer,
nothing is more important than jeemjam
absolutely.
 Jeemjam.com is proactively looking for
new opportunities for its users that
convince them to log in and search
further. There would be a couple of other
services you will adhere to in the future.
    </h5>
</div>
@endsection