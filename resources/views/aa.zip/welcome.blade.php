   @extends('layout')
    @section('content')
<div class="container-fluid px-4">
                        <div class="des" style="width:100%;margin-bottom:10px; ">
                            <div style="">
                            <center> 
                                <img style="width:100%;height:250px;" src="{{asset('FB PNJ.png')}}" alt="logo">
                           </center> 
                        </div>
                        <center>
                            <div style="margin-top:10px;width:200px;height:35px;background-color:green; border:1px solid green;border-radius:60px;">
                            <center><a style="text-decoration:none;color:black;"href="{{url('post/create')}}">Post your Ads for free</a></center>
                            </div></center>
                        </div>
                        <div class="mob">
                        <div class="col-xl-8 col-md-8">
                                <div class="card  mb-4">
                                    <div class="card-body"style="margin-top:10px;color:black;border-bottom:1px solid grey;"> 
                                    <h4 style="float:left;" >Select a Country</h4>
                                </div>
			
			
            <br>
            <br>
           <a style="color:black;text-decoration:none;" href="{{url('con/Algeria')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>
            Algeria</h5></span>
                    </a>  
                    <br>
                  <a style="color:black;text-decoration:none;" href="{{url('con/Bahrain')}}"> <span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Behrain.png')}}" alt="logo">Bahrain
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Egypt')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Egypt.png')}}" alt="logo">
                    Egypt</h5></a>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Alexandria')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Alexandria
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Cairo')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Cairo
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Delta')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Delta
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Upper Egypt')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Upper Egypt
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Emirates')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('UAE.png')}}" alt="logo">Emirates
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Abu Dhabi')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('UAE.png')}}" alt="logo">Abu Dhabi
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Ajman Emirate')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Ajman Emirate
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Al Ain')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Al Ain
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Dubai Emirate')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Dubai Emirate
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Fujairah')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Fujairah
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Ras Al-Khaimah')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Ras Al-Khaimah
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Sharjah Emirate')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Sharjah Emirate
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Umm Al Quwain')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Umm Al Quwain
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Iraq')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Iraq.png')}}" alt="logo">
                    Iraq</h5></a>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Baghdad')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Baghdad
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Basra Governorate')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Basra Governorate
                    </a></h5>  </span>
                    <br>
                   <span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><a style="color:black;text-decoration:none;" href="{{url('con/Jordan')}}"><img style="width:30px;height:30px;" src="{{asset('Jordan.png')}}" alt="logo">
                   Jordan</h5> </a>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Amman')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Amman
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Aqaba')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Aqaba
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Irbid')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Irbid
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Zarqaa')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Zarqaa
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Kuwait')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i> <img style="width:30px;height:30px;" src="{{asset('kuwat.png')}}" alt="logo">
             Kuwait</span>
    </h5>                </a>  
                    <br>
                  <a style="color:black;text-decoration:none;" href="{{url('con/Al Jahra Governorate')}}"> <span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Al Jahra Governorate
                    </a></h5> </span>
                    <br>
                   <span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Kuwait City
    </h5></a></span>
                      
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Tenth Region')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Tenth Region
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Lebanon')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Lebonan.png')}}" alt="logo">Lebanon
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Morocco')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Morroco.png')}}" alt="logo">Morocco
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Oman')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('oman.png')}}" alt="logo">Oman
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Qatar')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Qatar
        </span>
    </h5>                
                    </a>  
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Saudi Arabia')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Saudia.png')}}" alt="logo">Saudi Arabia
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Al Ahsa')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Al Ahsa
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Al Qassim')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Al Qassim
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Aseer Province')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Aseer Province
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Dammam')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Dammam
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Hail Province')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Hail Province
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Jeddah')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Jeddah
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Medina')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Medina
                    </a></h5>  </span>
                    <br>
                   <a style="color:black;text-decoration:none;" href="{{url('con/Riyadh')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i>Riyadh
                    </a></h5>  </span>
                    <br>
                    <a style="color:black;text-decoration:none;" href="{{url('con/Tabuk')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><a style="color:black;text-decoration:none;" href="{{url('con/Tabuk')}}">Tabuk
                    </a></h5>  </span>
                    <br>
                    <a style="color:black;text-decoration:none;" href="{{url('con/Pakistan')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><img style="width:30px;height:30px;" src="{{asset('Pak.png')}}" alt="logo">Pakistan</a>
</span>
    </h5>               
<br>
 <br>
                    <a style="color:black;text-decoration:none;" href="{{url('post/create')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h5><i style="float:right" class="fas fa-arrow-right"></i><a style="color:black;text-decoration:none;" href="{{url('post/create')}}">Post free advertisment
                    </a></h5>  </span>

                    
<br>
</div>
                    
    </div> 
                </div>
              <div class="des">
                        <div  class="row">
                            <div class="col-xl-4 col-md-5">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey;  background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-mobile"></i></h4></div>
                                    <h4 style="float:left;" >Mobile</h4>
                                </div>
                                @foreach($mobData as $data)
                                   
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.$data->sub_category.'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a></h5>
                                 </div>
                                  @endforeach
                            </div>
</div>
<div  class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-help"></i></h4></div>
                                    <h4 style="float:left;" >Miscellaneous</h4>
                                </div>
                                @foreach($misData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div> 
                                 @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4 style="float:left;" >Job</h4>
                                </div>
                                @foreach($jobData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                  @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-car"></i></h4></div>
                                    <h4 style="float:left;" >Cars</h4>
                                </div>
                                @foreach($carData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:50px;height:50px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                  @endforeach
                                </div>
</div>
<div style="float:left;"class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4 style="float:left;" >Services</h4>
                                </div>
                                @foreach($serData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:50px;height:50px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                @endforeach
                                </div>
</div>

                           
                            </div>
                        </div>

</div>
@endsection