@extends('layout')


    @section('content')
              <div class="container-fluid px-4">
                         <div class="des">
                        <div  class="row">
                            <div class="col-xl-4 col-md-5">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey;  background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-mobile"></i></h4></div>
                                    <h4 style="float:left;" >Mobiles</h4>
                                </div>
                                @foreach($mobData as $data)
                                   
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.$data->sub_category.'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{$data->sub_category}}</a></h5>
                                 </div>
                                  @endforeach
                            </div>
</div>
<div  class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-help"></i></h4></div>
                                    <h4 style="float:left;" >Miscellaneous</h4>
                                </div>
                                @foreach($misData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div> 
                                 @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4 style="float:left;" >Jobs</h4>
                                </div>
                                @foreach($jobData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:70px;height:70px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                  @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-car"></i></h4></div>
                                    <h4 style="float:left;" >Cars</h4>
                                </div>
                                @foreach($carData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:50px;height:50px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                  @endforeach
                                </div>
</div>
<div style="float:left;"class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:white;border-bottom:1px solid grey; background-color: #06416c;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4><i class="fas fa-book"></i></h4></div>
                                    <h4 style="float:left;" >Services</h4>
                                </div>
                                @foreach($serData as $data)
                                <div style="float:left;;width:100%;margin-top:5px;">
                                <img style="float:left;width:50px;height:50px;" src="{{asset('Images/'.str_replace('?','',$data->sub_category).'.png')}}" alt="logo">
                                <h5 style="float:left;"><a class="nav-link" style="color:black;"   href="{{url('post/'.session('cat').'/'.$data->sub_category)}}">{{str_replace('?','',$data->sub_category)}}</a></h5>
                                 </div>
                                @endforeach
                                </div>
</div>

                           
                            </div>
                        </div>

</div>
         <div class="mob">
                        <div class="col-xl-4 col-md-5">
                                <div class="card  mb-4">
                                    <div class="card-body"style="margin-top:10px;color:black;border-bottom:1px solid black; background-color: white;;"> 
                                    <h4 style="float:left;" >Select a Category</h4>
                                </div>
			   </a>  
                    <br>
                    
                                    <div class="card-body"style="color:black;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4 style="font-size:30px"><i class="fas fa-mobile"></i></h4></div>
                                    <a style=" font-size:30px;color:black;text-decoration:none;" href="{{url('sub/mobile')}}"><h4><i style="float:right" class="fas fa-arrow-right"></i>Mobiles
                    </a></h4> 
                                </div>
                                <br>
                                
                                    <div class="card-body"style="color:black;;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4 style="font-size:30px"><i class="fas fa-car"></i></h4></div>
                                    <a style=" font-size:30px;color:black;text-decoration:none;" href="{{url('sub/cars')}}"><h4><i style="float:right" class="fas fa-arrow-right"></i>Cars
                    </a></h4> 
                                
                                 </div>
                    <br>
                   
                                    <div class="card-body"style="color:black;; "> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4 style="font-size:30px"><i class="fas fa-book"></i></h4></div>
                                    <a style=" font-size:30px;color:black;text-decoration:none;" href="{{url('sub/service')}}"><h4><i style="float:right" class="fas fa-arrow-right"></i>Services</a> </h4 >
                   
                               
                   </div>
                   
                    <br>
                    
                                    <div class="card-body"style="color:black "> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4 style="font-size:30px"><i  class="fas fa-help"></i></h4></div>
                                    <a style="font-size:30px;color:black;text-decoration:none;" href="{{url('sub/miscallenious')}}"><h4><i style="float:right" class="fas fa-arrow-right"></i>Miscallenious
                    </a></h4>  
                    
                                </div>
                   <br>
                   
                                    <div class="card-body"style="color:black; "> 
                                    <div style="float:left;"class="sb-nav-link-icon"><h4 style="font-size:30px"><i  class="fas fa-user"></i></h4></div>
                                    <a style="font-size:30px;color:black;text-decoration:none;" href="{{url('sub/jobs')}}"><h4><i style="float:right" class="fas fa-arrow-right"></i>Jobs
                    </a></h4>  
                                </div>
                  
                    <br>
                    <br>
   <a style="color:black;text-decoration:none;" href="{{url('post/create')}}"><span style="width:100%;margin-top:10px; border-bottom:1px solid grey;"> <h4 style="font-size:30px;"><i style="float:right" class="fas fa-arrow-right"></i><a style="color:black;text-decoration:none;" href="{{url('post/create')}}">Post free advertisment
                    </a></h4>  </span>

                    
<br>
</div>
                    
    </div> 
                
@endsection