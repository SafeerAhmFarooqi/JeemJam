@extends('layout')
@section('content')

<div class="container-fluid px-4">
                        <div style="width:100%;margin-bottom:10px; ">
                            <div style="">
                            <center> 
                                <img style="width:150px;height:150px;" src="{{asset('1 (1).jpeg')}}" alt="logo">
                           </center> 
                        </div>
                        <center>
                            <div style="margin-top:10px;width:200px;height:30px;background-color:green; border:1px solid green;border-radius:60px;">
                                <center><a style="text-decoration:none;"href="">Post your Ads for free</a></center>
                            </div></center>
                        </div>
                        <div class="mob">
                        <div class="col-xl-4 col-md-5">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <h4 style="float:left;" >Countries</h4>
                                </div>
			
            <br>
            <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Algeria')}}">Algeria
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Bahrain')}}">Bahrain
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Egypt')}}">Egypt
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Alexandria')}}">Alexandria
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Cairo')}}">Cairo
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Delta')}}">Delta
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Upper Egypt')}}">Upper Egypt
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Emirates')}}">Emirates
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Abu Dhabi')}}">Abu Dhabi
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Ajman Emirate')}}">Ajman Emirate
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Al Ain')}}">Al Ain
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Dubai Emirate')}}">Dubai Emirate
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Fujairah')}}">Fujairah
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Ras Al-Khaimah')}}">Ras Al-Khaimah
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Sharjah Emirate')}}">Sharjah Emirate
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Umm Al Quwain')}}">Umm Al Quwain
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Iraq')}}">Iraq
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Baghdad')}}">Baghdad
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Basra Governorate')}}">Basra Governorate
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Jordan')}}">Jordan
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Amman')}}">Amman
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Aqaba')}}">Aqaba
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Irbid')}}">Irbid
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Zarqaa')}}">Zarqaa
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Kuwait')}}">Kuwait
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Al Jahra Governorate')}}">Al Jahra Governorate
</h6>
                    </a> 
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Kuwait City')}}">Kuwait City
    </h6>
    

                 
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Tenth Region')}}">Tenth Region
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Lebanon')}}">Lebanon
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Morocco')}}">Morocco
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Oman')}}">Oman
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Qatar')}}">Qatar
          </h6>
                    
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Saudi Arabia')}}">Saudi Arabia
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Al Ahsa')}}">Al Ahsa
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Al Qassim')}}">Al Qassim
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Aseer Province')}}">Aseer Province
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Dammam')}}">Dammam
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Hail Province')}}">Hail Province
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Jeddah')}}">Jeddah
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Medina')}}">Medina
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Riyadh')}}">Riyadh
</h6>
                    </a>  
                    <br>
                   <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Tabuk')}}">Tabuk
</h6>
                    </a>  
                    <br>
                  <h6> <a style="color:black;text-decoration:none;" href="{{url('post?con=Pakistan')}}">Pakistan</a>
</h6>

<br>
</div>
                    
    </div> 
                </div>
                        <div  class="row">
                            <div class="col-xl-4 col-md-5">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><i class="fas fa-mobile"></i></div>
                                    <h4 style="float:left;" >Mobile</h4>
                                </div>
                                @foreach($mobData as $data)
                                   
                                <h6 style="color:black;" ><a class="nav-link" style="color:black;"  href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a></h6>
                                @endforeach
                            </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><i class="fas fa-help"></i></div>
                                    <h4 style="float:left;" >Miscellaneous</h4>
                                </div>
                                @foreach($misData as $data)
                                    <h6><a class="nav-link" style="color:black;"   href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a></h6>
                                @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                    <h4 style="float:left;" >Job</h4>
                                </div>
                                @foreach($jobData as $data)
                                    <h6><a class="nav-link" style="color:black;"   href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a></h6>
                                @endforeach
                                </div>
</div>
<div class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><i class="fas fa-car"></i></div>
                                    <h4 style="float:left;" >Cars</h4>
                                </div>
                                @foreach($carData as $data)
                                    <h6><a class="nav-link" style="color:black;"   href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a></h6>
                                @endforeach
                                </div>
</div>
<div style="float:left;"class="col-xl-4 col-md-6">
                                <div class="card  text-white mb-4">
                                    <div class="card-body"style="color:black;border-bottom:1px solid grey;"> 
                                    <div style="float:left;"class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                    <h4 style="float:left;" >Services</h4>
                                </div>
                                @foreach($serData as $data)
                                    <h6><a class="nav-link" style="color:black;"   href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a></h6>
                                @endforeach
                                </div>
</div>
                           
                            </div>
                        </div>


@endsection