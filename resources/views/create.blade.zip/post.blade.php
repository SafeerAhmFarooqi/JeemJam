@extends('lay')
@section('content')
<div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav style="border-right:1px solid grey; background:blue;color:white;" class="sb-sidenav accordion sb-sidenav" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Home</div>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="{{url('/')}}">
                                <div class="sb-nav-link-icon" ><i class="fas fa-home"></i></div>
                                Home
                            </a>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="{{url('login')}}">
                                <div class="sb-nav-link-icon" ><i class="fas fa-home"></i></div>
                               Sign in
                            </a>
                            <div class="sb-sidenav-menu-heading">Categories</div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-mobile"></i></div>
                                Mobile
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                    @foreach($mobData as $data)
                                    <a class="nav-link"  style="color:white;"  href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a>
                                   @endforeach
                                </nav>
                            </div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Service
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                @foreach($serData as $data)
                                    <a class="nav-link"  style="color:white;"  href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a>
                                   @endforeach 
                                </nav>
                            </div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-help"></i></div>
                                Miscellaneous
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                @foreach($misData as $data)
                                    <a class="nav-link"  style="color:white;"  href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a>
                                   @endforeach    
                                </nav>
                            </div>
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Jobs
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                @foreach($jobData as $data)
                                    <a class="nav-link"  style="color:white;"  href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a>
                                   @endforeach
                                </nav>
                            </div>
                          
                            <a class="nav-link collapsed" style="color:white;" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-car"></i></div>
                               Cars
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" style="color:white;" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav  class="sb-sidenav-menu-nested nav">
                                @foreach($carData as $data)
                                    <a class="nav-link"  style="color:white;"  href="{{url('post?sub='.$data->sub_category)}}">{{$data->sub_category}}</a>
                                   @endforeach
                                </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Pages</div>
                            <a class="nav-link"  style="color:white;"style="color:white;" href="{{url('/about')}}">
                                About Us
                            </a>
                            <a class="nav-link"  style="color:white;"style="color:white;"  href="{{url('/contact')}}">
                                Contact Us
                            </a>
            
                            <a class="nav-link"  style="color:white;"style="color:white;"  href="{{url('/privacy')}}">
                                Privacy Policy
                            </a>
                            
                        </div>
                    </div>
                   
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
<div style="width:98%;border:1px solid grey;background-color:white;">
    <center><h1 style="font-size:60px;"> <u>Post</u> </h1></center> 
    <div style="border:1px solid black;background-color:white;">
    <div style="float:left;background-color:white;">
            <img style="float:left;width:150px;height:150px;margin-left:5px;" src="{{asset('1 (3).jpeg')}}" alt="logo">
           <h6 style="margin-top:35px;">Required Philipina or Nepalese waitress & cashier for famous cafe in Dubai we prefer the laddy witch she has residence visa experience not less than one year in same field please contact me in ​/ Mobile & Whatsapp: 050 646 2881Email: hussein.tayyem@hotmail.com
      </h6>   <a href="">Show More</a>
    </div>
    @foreach($postData as $data)
        <div style="float:left;background-color:white;">
            <img style="float:left;width:150px;height:150px;margin-left:5px;" src="{{asset('1 (3).jpeg')}}" alt="logo">
           <h6 style="margin-top:35px;">{{substr($data->content,0,100)}} </h6>   <a href="">Show More</a>
    </div>
    @endforeach
    </div>
  </div>
</main>
@endsection