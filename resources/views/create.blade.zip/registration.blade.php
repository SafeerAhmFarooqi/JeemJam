<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background:#f5eeee;
        }
        .login{
            width:400px;
            margin: auto;
            top:50%;
            padding: 10px;
            text-align: center;
            border:1px solid #d3caca;
        }
        .text{
            width:100%;
            margin: auto;
            top:50%;
            padding: 10px;
            text-align: center;
        }
        input{
            width:90%;
            height: 35px;
            margin-bottom:10px;
        }
        table{
            width:100%;
            font-size:25px;
        }
        #submit{
            background-color: #a1a1dd;
            font-size:20px;
            border:0px;
            border-radius:15px;
            color:white;
        }
        #logo{
            width: 70px;
            height: 70px;
        }
    </style>
</head>
<body>
    <div class="login">
        @if($errors)
        @foreach($errors->all() as $error)
        <p style="color:red;">{{$error}}</p>
        @endforeach
        @endif
        @if(Session::has('error'))
        <p style="color:red;">{{session('error')}}</p>
        @endif
        <form method="post">
            @csrf
    <table>
        <tr>
            <img src="{{asset('1 (3).jpeg')}}" alt="logo" id="logo">
        </tr>
            <tr>
                <h1> <i>Register</i> </h1>
            </tr>
                
            <tr>
                <td> <input type="number" name="username" id="username" placeholder="Phone_no">
                </td>
            </tr>
            <tr>
                <td> <input type="text" name="name" id="name" placeholder="Full Name">
                </td>
            </tr>
            <tr>
                <td>
                     <input type="password" name="password" id="password"  placeholder="Password">
                </td>
            </tr>
            <tr>
                <td>
                     <input type="submit" value="Sign Up" id="submit">
                </td>
            </tr>
    </table></form>
</div>

</body>
</html>